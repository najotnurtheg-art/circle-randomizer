export const dynamic = 'force-dynamic';
export const revalidate = 0;

import RegisterForm from './RegisterForm';

export default function Page() {
  return <RegisterForm />;
}
