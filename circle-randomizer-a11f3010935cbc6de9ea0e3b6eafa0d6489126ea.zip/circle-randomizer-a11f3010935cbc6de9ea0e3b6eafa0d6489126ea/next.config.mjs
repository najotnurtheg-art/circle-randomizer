/** @type {import('next').NextConfig} */
const nextConfig = {
  // Keep SSR/ISR enabled (do NOT set output:'export')
};

export default nextConfig;
